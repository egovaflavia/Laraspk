<?php $__env->startSection('content'); ?>
<div class="pricing-header px-3 py-3 pt-md-3 pb-md-4 mx-auto text-center">
    <h1 class="display-6">Perhitungan</h1>
</div>

<div class="container">
    <div class="mb-4">
        <div class="table-responsive">
            <h4>Penilaian</h4>
            <table class="table table-bordered ">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama Supplier</th>
                        <th>Quality</th>
                        <th>Cost</th>
                        <th>Delivery</th>
                        <th>Responsiveness</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e(++$no); ?></td>
                        <td><?php echo e($row->relSupplier->supplier_nama); ?></td>
                        <td><?php echo e($row->relC1->sub_kriteria_nama); ?></td>
                        <td><?php echo e($row->relC2->sub_kriteria_nama); ?></td>
                        <td><?php echo e($row->relC3->sub_kriteria_nama); ?></td>
                        <td><?php echo e($row->relC4->sub_kriteria_nama); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6">TIdak ada data</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>

            <h4>Normalisasi</h4>
            <table class="table table-bordered ">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama Supplier</th>
                        <th>Quality</th>
                        <th>Cost</th>
                        <th>Delivery</th>
                        <th>Responsiveness</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e(++$no); ?></td>
                        <td><?php echo e($row->relSupplier->supplier_nama); ?></td>
                        <td><?php echo e($row->relC1->sub_kriteria_nilai); ?></td>
                        <td><?php echo e($row->relC2->sub_kriteria_nilai); ?></td>
                        <td><?php echo e($row->relC3->sub_kriteria_nilai); ?></td>
                        <td><?php echo e($row->relC4->sub_kriteria_nilai); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6">TIdak ada data</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>

            <h4>Nilai Profil Standar</h4>
            <table class="table table-bordered ">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama Supplier</th>
                        <th>Quality</th>
                        <th>Cost</th>
                        <th>Delivery</th>
                        <th>Responsiveness</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e(++$no); ?></td>
                        <td><?php echo e($row->relSupplier->supplier_nama); ?></td>
                        <td><?php echo e($row->relC1->sub_kriteria_nilai); ?></td>
                        <td><?php echo e($row->relC2->sub_kriteria_nilai); ?></td>
                        <td><?php echo e($row->relC3->sub_kriteria_nilai); ?></td>
                        <td><?php echo e($row->relC4->sub_kriteria_nilai); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6">TIdak ada data</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
                <tfoot>

                    <tr>
                        <th colspan="2" class="bg-primary">
                            Nilai Profil Standar</th>
                        <?php $__currentLoopData = $dataProfil; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rProfil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <th class="bg-primary"><?php echo e($rProfil->relSubKriteria->sub_kriteria_nilai); ?></th>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                </tfoot>
            </table>

            <h4>Gap Penilaian dan Profil Standar</h4>
            <table class="table table-bordered ">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama Supplier</th>
                        <th>Quality</th>
                        <th>Cost</th>
                        <th>Delivery</th>
                        <th>Responsiveness</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $dataPerhitungan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e(++$no); ?></td>
                        <td><?php echo e($row->relSupplier->supplier_nama); ?></td>
                        <td><?php echo e($row->hasil_profil_c1); ?></td>
                        <td><?php echo e($row->hasil_profil_c2); ?></td>
                        <td><?php echo e($row->hasil_profil_c3); ?></td>
                        <td><?php echo e($row->hasil_profil_c4); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6">TIdak ada data</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>

            <h4>Nilai Gap</h4>
            <table class="table table-bordered ">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama Supplier</th>
                        <th>Quality</th>
                        <th>Cost</th>
                        <th>Delivery</th>
                        <th>Responsiveness</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $dataPerhitungan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e(++$no); ?></td>
                        <td><?php echo e($row->relSupplier->supplier_nama); ?></td>
                        <td><?php echo e($row->hasil_gap_c1); ?></td>
                        <td><?php echo e($row->hasil_gap_c2); ?></td>
                        <td><?php echo e($row->hasil_gap_c3); ?></td>
                        <td><?php echo e($row->hasil_gap_c4); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6">TIdak ada data</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>

            <h4>Nilai Rata-Rata</h4>
            <table class="table table-bordered ">
                <thead>
                    <tr>
                        <th rowspan="2" class="text-center">No</th>
                        <th rowspan="2" class="text-center">Nama Supplier</th>
                        <th colspan="2" class="text-center">Core Factor</th>
                        <th colspan="2" class="text-center">Secondary Factor</th>
                    </tr>
                    <tr>
                        <th class="text-center">Quality</th>
                        <th class="text-center">Cost</th>
                        <th class="text-center">Delivery</th>
                        <th class="text-center">Responsiveness</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $dataPerhitungan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e(++$no); ?></td>
                        <td><?php echo e($row->relSupplier->supplier_nama); ?></td>
                        <td colspan="2" class="text-center"><?php echo e($row->hasil_core); ?></td>
                        <td colspan="2" class="text-center"><?php echo e($row->hasil_second); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6">TIdak ada data</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <h4>Total Nilai</h4>
        <table class="table table-bordered ">
            <thead>
                <tr>
                    <th width="2" class="text-center">No</th>
                    <th class="text-center">Nama Supplier</th>
                    <th class="text-center">Total</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $dataPerhitungan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e(++$no); ?></td>
                    <td><?php echo e($row->relSupplier->supplier_nama); ?></td>
                    <td class="text-center"><?php echo e($row->total); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="6">TIdak ada data</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>

        <h4>Perengkingan</h4>
        <table class="table table-bordered ">
            <thead>
                <tr>
                    <th width="2" class="text-center">No</th>
                    <th class="text-center">Nama Supplier</th>
                    <th class="text-center">Total</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    $no = 1;
                ?>
                <?php $__empty_1 = true; $__currentLoopData = $dataPerhitungan->SortByDesc('total'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($no++); ?></td>
                    <td><?php echo e($row->relSupplier->supplier_nama); ?></td>
                    <td class="text-center"><?php echo e($row->total); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="6">TIdak ada data</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/Laraject/Laraspk/resources/views/page/perhitungan/index.blade.php ENDPATH**/ ?>