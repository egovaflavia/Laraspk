<?php $__env->startSection('content'); ?>
<div class="pricing-header px-3 py-3 pt-md-3 pb-md-4 mx-auto text-center">
    <h1 class="display-6">List Data Profil Standar</h1>
</div>

<div class="container">
    <div class="mb-4">
        <p><center>
            Profil Standar yang Dipilih (Dicari).
        </center></p>
        <div class="row d-flex justify-content-center">
            <div class="col-md-10 ">
                <div class="table-responsive">
                    <table class="table table-bordered ">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Kriteria</th>
                                <th>Sub Kriteria yg Dipilih</th>
                                <th>Nilai Profil Standar yg Dipilih</th>
                                <th>#</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e(++$no); ?></td>
                                <td><?php echo e($row->relKriteria->kriteria_nama); ?></td>
                                <td><?php echo e($row->relSubKriteria->sub_kriteria_nama); ?></td>
                                <td><?php echo e($row->relSubKriteria->sub_kriteria_nilai); ?></td>
                                <td>
                                    <a class="btn btn-sm btn-warning text-bold"
                                    href="<?php echo e(route('profil_standar.edit', ['profil_standar' => $row])); ?>">
                                        <strong>Edit</strong>
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="6" ><center>Tidak ada data</center></td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/Laraject/Laraspk/resources/views/page/profil_standar/index.blade.php ENDPATH**/ ?>