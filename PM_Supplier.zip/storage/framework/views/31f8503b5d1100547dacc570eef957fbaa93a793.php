<?php $__env->startSection('content'); ?>
<div class="pricing-header px-3 py-3 pt-md-3 pb-md-4 mx-auto text-center">
    <h1 class="display-6">Tambah Data Penilaian</h1>
</div>

<div class="container">
    <div class="mb-4">
        <a href="<?php echo e(route('penilaian.index')); ?>" class="btn btn-sm btn-primary mb-3"><strong>Kembali</strong></a>
        <div class="row">
            <div class="col-md-5 order-md-2 mb-4">
                <h4 class="d-flex justify-content-between align-items-center mb-3">
                    <span class="text-muted">Kriteria</span>
                </h4>
                <ul class="list-group mb-3">
                    <?php $__empty_1 = true; $__currentLoopData = $dataKriteria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <li class="list-group-item d-flex justify-content-between lh-condensed">
                            <div>
                                <h6 class="my-0"><?php echo e($r->kriteria_nama); ?></h6>
                                <small class="text-muted"><?php echo e($r->kriteria_jenis); ?></small>
                            </div>
                            <span class="text-muted"><?php echo e($r->kriteria_bobot); ?></span>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        Tidak ada data
                    <?php endif; ?>

                </ul>

            </div>
            <div class="col-md-7 order-md-1">
                <h4 class="mb-3">Data Penilaian</h4>
                <form class="needs-validation"
                    action="<?php echo e(route($route, $row->perhitungan_id ?? null)); ?>"
                    method="POST">
                    <?php echo csrf_field(); ?>
                    <?php if(isset($row)): ?>
                        <?php echo method_field('PATCH'); ?>
                    <?php endif; ?>

                    <?php if(isset($row)): ?>
                    <div class="form-group">
                        <label for="name">Supplier</label>
                        <input type="text" class="form-control" value="<?php echo e($row->relSupplier->supplier_nama); ?>" disabled>
                    </div>
                    <?php else: ?>
                        <?php if(isset($suppliers)): ?>
                            <?php if($errors->has('supplier_id')): ?>
                            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                <?php echo e($errors->first('supplier_id')); ?>

                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <?php endif; ?>
                            <div class="mb-3">
                                <label for="name">Supplier</label>
                                <select name="supplier_id"
                                    class="form-control <?php $__errorArgs = ['supplier_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    id="supplier_id">
                                    <option value="">Pilih</option>
                                    <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dataSupplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($dataSupplier->supplier_id); ?>"><?php echo e($dataSupplier->supplier_nama); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        <?php endif; ?>
                    <?php endif; ?>

                    <div class="mb-3">
                        <label for="perhitungan_c1">Quality</label>
                        <?php if($errors->has('perhitungan_c1')): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <?php echo e($errors->first('perhitungan_c1')); ?>

                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <?php endif; ?>
                        <div class="input-group">
                            <select class="form-control"
                                name="perhitungan_c1"
                                id="perhitungan_c1" required>
                                <option value="">Pilih</option>
                                <?php $__currentLoopData = $perhitungan_c1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rc1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($rc1->sub_kriteria_id); ?>"
                                        <?php if(isset($row)): ?>
                                        <?php echo e($row->perhitungan_c1 == $rc1->sub_kriteria_id ? 'selected' : ''); ?>

                                        <?php endif; ?>>
                                        <?php echo e($rc1->sub_kriteria_nama); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label for="perhitungan_c2">Cost</label>
                        <?php if($errors->has('perhitungan_c2')): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <?php echo e($errors->first('perhitungan_c2')); ?>

                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <?php endif; ?>
                        <div class="input-group">
                            <select class="form-control"
                                name="perhitungan_c2"
                                id="perhitungan_c2" required>
                                <option value="">Pilih</option>
                                <?php $__currentLoopData = $perhitungan_c2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rc2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($rc2->sub_kriteria_id); ?>"
                                    <?php if(isset($row)): ?>
                                    <?php echo e($row->perhitungan_c2 == $rc2->sub_kriteria_id ? 'selected' : ''); ?>

                                    <?php endif; ?>>
                                    <?php echo e($rc2->sub_kriteria_nama); ?>

                                </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>

                        </div>
                    </div>

                    <div class="mb-3">
                        <label for="perhitungan_c3">Delivery</label>
                        <?php if($errors->has('perhitungan_c3')): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <?php echo e($errors->first('perhitungan_c3')); ?>

                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <?php endif; ?>
                        <div class="input-group">
                            <select class="form-control"
                                name="perhitungan_c3"
                                id="perhitungan_c3" required>
                                <option value="">Pilih</option>
                                <?php $__currentLoopData = $perhitungan_c3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rc3): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($rc3->sub_kriteria_id); ?>"
                                    <?php if(isset($row)): ?>
                                    <?php echo e($row->perhitungan_c3 == $rc3->sub_kriteria_id ? 'selected' : ''); ?>

                                    <?php endif; ?>>
                                    <?php echo e($rc3->sub_kriteria_nama); ?>

                                </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>

                        </div>
                    </div>

                    <div class="mb-3">
                        <label for="perhitungan_c4">Responsiveness</label>
                        <?php if($errors->has('perhitungan_c4')): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <?php echo e($errors->first('perhitungan_c4')); ?>

                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <?php endif; ?>
                        <div class="input-group">
                            <select class="form-control"
                                name="perhitungan_c4"
                                id="perhitungan_c4" required>
                                <option value="">Pilih</option>
                                <?php $__currentLoopData = $perhitungan_c4; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rc4): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($rc4->sub_kriteria_id); ?>"
                                    <?php if(isset($row)): ?>
                                    <?php echo e($row->perhitungan_c4 == $rc4->sub_kriteria_id ? 'selected' : ''); ?>

                                    <?php endif; ?>>
                                    <?php echo e($rc4->sub_kriteria_nama); ?>

                                </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>

                        </div>
                    </div>

                    <hr class="mb-4">
                    <button class="btn btn-primary btn-lg btn-block" type="submit">Simpan</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/Laraject/Laraspk/resources/views/page/penilaian/form.blade.php ENDPATH**/ ?>