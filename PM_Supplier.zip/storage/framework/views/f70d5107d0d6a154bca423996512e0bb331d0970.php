<?php $__env->startSection('content'); ?>
<div class="pricing-header px-3 py-3 pt-md-3 pb-md-4 mx-auto text-center">
    <h1 class="display-6">Tambah Data Supplier</h1>
</div>

<div class="container">
    <div class="mb-4">
        <a href="<?php echo e(route('supplier.index')); ?>" class="btn btn-sm btn-primary mb-3"><strong>Kembali</strong></a>
        <div class="row">
            <div class="col-md-5 order-md-2 mb-4">
                <h4 class="d-flex justify-content-between align-items-center mb-3">
                    <span class="text-muted">Latest Data</span>
                </h4>
                <ul class="list-group mb-3">
                    <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <li class="list-group-item d-flex justify-content-between lh-condensed">
                            <div>
                                <h6 class="my-0"><?php echo e($r->supplier_nama); ?></h6>
                                <small class="text-muted"><?php echo e($r->supplier_notlp); ?></small>
                            </div>
                            <span class="text-muted"><?php echo e($r->supplier_email); ?></span>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        Tidak ada data
                    <?php endif; ?>

                </ul>

            </div>
            <div class="col-md-7 order-md-1">
                <h4 class="mb-3">Data Supplier</h4>
                <form class="needs-validation"
                    action="<?php echo e(route($route, $row->supplier_id ?? null)); ?>"
                    method="POST">
                    <?php echo csrf_field(); ?>
                    <?php if(isset($row)): ?>
                        <?php echo method_field('PATCH'); ?>
                    <?php endif; ?>

                    <div class="mb-3">
                        <label for="supplier_nama">Nama Supplier</label>
                        <?php if($errors->has('supplier_nama')): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <?php echo e($errors->first('supplier_nama')); ?>

                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <?php endif; ?>
                        <div class="input-group">
                            <input type="text"
                                class="form-control"
                                id="supplier_nama"
                                name="supplier_nama"
                                placeholder="Nama Supplier"
                                value="<?php echo e(old('supplier_nama') ?? $row->supplier_nama ?? ''); ?>">
                        </div>
                    </div>

                    <div class="mb-3">
                        <label for="supplier_email">Email Supplier </label>
                        <?php if($errors->has('supplier_email')): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <?php echo e($errors->first('supplier_email')); ?>

                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <?php endif; ?>
                        <input type="text"
                            class="form-control"
                            id="supplier_email"
                            name="supplier_email"
                            placeholder="you@example.com"
                            value="<?php echo e(old('supplier_email') ?? $row->supplier_email ?? ''); ?>">
                    </div>

                    <div class="mb-3">
                        <label for="supplier_notlp">No Telp</label>
                        <?php if($errors->has('supplier_notlp')): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <?php echo e($errors->first('supplier_notlp')); ?>

                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <?php endif; ?>
                        <div class="input-group">
                            <input type="text"
                                class="form-control"
                                id="supplier_notlp"
                                name="supplier_notlp"
                                placeholder="No Tlp"
                                value="<?php echo e(old('supplier_notlp') ?? $row->supplier_notlp ?? ''); ?>">
                        </div>
                    </div>

                    <div class="mb-3">
                        <label for="alamat">Alamat</label>
                        <?php if($errors->has('supplier_alamat')): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <?php echo e($errors->first('supplier_alamat')); ?>

                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <?php endif; ?>
                        <div class="input-group">
                            <textarea   name="supplier_alamat"
                                        id="supplier_alamat"
                                        class="form-control"
                                        rows="3"><?php echo e(old('supplier_alamat') ?? $row->supplier_alamat ?? ''); ?>

                            </textarea>
                        </div>
                    </div>

                    <hr class="mb-4">
                    <button class="btn btn-primary btn-lg btn-block" type="submit">Simpan</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/Laraject/Laraspk/resources/views/page/supplier/form.blade.php ENDPATH**/ ?>