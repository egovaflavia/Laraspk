<?php $__env->startSection('content'); ?>
<div class="pricing-header px-3 py-3 pt-md-3 pb-md-4 mx-auto text-center">
    <h1 class="display-6">List Data User</h1>
</div>

<div class="container">
    <div class="mb-4">
        <a href="<?php echo e(route('user.create')); ?>" class="btn btn-sm btn-primary mb-3"><strong>Tambah</strong></a>
        <?php if(session('message')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo e(session()->get('message')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <?php endif; ?>
        <div class="table-responsive">
            <table class="table table-bordered ">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama</th>
                        <th>Email</th>
                        <th>Username</th>
                        <th>Level</th>
                        <th>#</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e(++$no); ?></td>
                        <td><?php echo e($row->name); ?></td>
                        <td><?php echo e($row->email); ?></td>
                        <td><?php echo e($row->username); ?></td>
                        <td><?php echo e($row->level); ?></td>
                        <td>
                            <a class="btn btn-sm btn-warning"
                                href="<?php echo e(route('user.edit', ['user' => $row])); ?>">
                                    <strong>Edit</strong></a>

                            <form action="<?php echo e(route('user.destroy', ['user' => $row])); ?>"
                                style="display:inline-block"
                                name="formDelete"
                                method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button class="btn btn-sm btn-danger"
                                    type="submit">
                                    <strong>Hapus</strong>
                                </button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6">TIdak ada data</td>
                    </tr>
                    <?php endif; ?>


                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/Laraject/Laraspk/resources/views/page/user/index.blade.php ENDPATH**/ ?>