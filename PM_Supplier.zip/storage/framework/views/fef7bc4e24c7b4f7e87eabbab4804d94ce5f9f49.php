<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@400;500&display=swap" rel="stylesheet">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css"
        integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    <style>
        * {
            font-family: 'Quicksand', sans-serif;
        }
    </style>

    <title><?php echo e(config('app.name', 'Aplikasi')); ?></title>
</head>

<body>

    <div class="d-flex flex-column flex-md-row align-items-center p-3 px-md-4 mb-3 bg-white border-bottom shadow-sm">
        <h5 class="my-0 mr-md-auto font-weight-normal">Sistem Pendukung Keputusan</h5>
        <nav class="my-2 my-md-0 mr-md-3">
            <?php if(auth()->guard()->guest()): ?>
                <a class="p-2 text-dark" href="<?php echo e(route('login')); ?>">Login</a>
            <?php endif; ?>
            <?php if(auth()->guard()->check()): ?>
                <a class="p-2 text-dark" href="#">Home</a>
                <a class="p-2 text-dark" href="#">User</a>
                <a class="p-2 text-dark" href="#">Supplier</a>
                <a class="p-2 text-dark" href="#">Kriteira</a>
                <a class="p-2 text-dark" href="#">Sub Kriteria</a>
                <a class="p-2 text-dark" href="#">Profil Standar</a>
                <a class="p-2 text-dark" href="#">GAP</a>
            <?php endif; ?>
        </nav>
        <?php if(auth()->guard()->check()): ?>
            <a class="btn btn-outline-primary" href="<?php echo e(route('logout')); ?>">Logout</a>
        <?php endif; ?>
    </div>

    <div class="pricing-header px-3 py-3 pt-md-5 pb-md-4 mx-auto text-center">
        <h1 class="display-4">Profile Matching</h1>
        <p class="lead">Implementasi  Metode Profile Matching Untuk Mengetahui Supplier Terbaik <br> Pada Toko Berkah Elektronilk & Furniture</p>
    </div>

    <div class="container">
        <div class="mb-3 text-center">
            <div class="mb-4">
                <p>
                    Profile Matching adalah sebuah mekanisme pengambilan keputusan dengan mengasumsikan bahwa terdapat tingkat variabel prediktor yang ideal yang harus dipenuhi oleh subyek yang diteliti, bukannya tingkat minimal yang harus dipenuhi atau dilewati. Contoh penerapnnya, seperti: evaluasi kinerja karyawan, penerimaan beasiswa, dan lainnya sebagainya.
                </p>
            </div>
        </div>

        <footer class="pt-4 my-md-5 pt-md-5 border-top">
            <div class="row">
                <div class="col-12 col-md">
                    <img class="mb-2" src="<?php echo e(asset('public/logo.jpeg')); ?>" alt="" width="60" height="24">
                    <small class="d-block mb-3 text-muted">&copy; SPK PM XGV</small>
                </div>
                <div class="col-6 col-md">

                </div>
                <div class="col-6 col-md">
                    <h5>Menu</h5>
                    <ul class="list-unstyled text-small">
                        <?php if(auth()->guard()->check()): ?>
                            <li><a class="text-muted" href="#">Home</a></li>
                            <li><a class="text-muted" href="#">User</a></li>
                            <li><a class="text-muted" href="#">Supplier</a></li>
                            <li><a class="text-muted" href="#">Kriteira</a></li>
                        <?php endif; ?>
                    </ul>
                </div>
                <div class="col-6 col-md">
                    <ul class="list-unstyled text-small">
                        <?php if(auth()->guard()->guest()): ?>
                            <li><a class="text-muted" href="<?php echo e(route('login')); ?>">Login</a></li>
                        <?php endif; ?>
                        <?php if(auth()->guard()->check()): ?>
                            <li><a class="text-muted" href="#">Sub Kriteria</a></li>
                            <li><a class="text-muted" href="#">Profil Standar</a></li>
                            <li><a class="text-muted" href="#">GAP</a></li>
                            <li><a class="text-muted" href="#">Logout</a></li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </footer>
    </div>1

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
        integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.7/dist/umd/popper.min.js"
        integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/js/bootstrap.min.js"
        integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous">
    </script>
</body>

</html>
<?php /**PATH /opt/lampp/htdocs/Laraject/Laraspk/resources/views/dashboard.blade.php ENDPATH**/ ?>